#import <Foundation/Foundation.h>

extern NSArray<NSNumber *> *ObtainNetworkCounters(void);
