#import <AVFoundation/AVFoundation.h>

extern NSString *const kVigoAVPlayerItemSeekStartedNotificationName;
extern NSString *const kVigoAVPlayerItemSeekFinishedNotificationName;

extern NSString *const kVigoAVPlayerItemSeekTimeKey;
extern NSString *const kVigoAVPlayerItemSeekResultKey;

@interface AVPlayerItem (AdditionalEvents)

@end
