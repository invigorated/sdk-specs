package one.vigo;

import android.util.Log;

import vigo.sdk.FeedbackOptions;
import vigo.sdk.VigoBootstrapBuilder;
import vigo.sdk.VigoSession;
import vigo.sdk.scenarios.LocationScenario;
import vigo.sdk.scenarios.PerceptionScenario;

import android.content.Context;
import java.util.Map;

public class VigoSdk {
    VigoSession vigoSession = null;
    VigoBootstrapBuilder vigoBootstrapBuilder = null;

    public void initBootstrapBuilder(Context ctx, String clientId) {
        vigoBootstrapBuilder = VigoBootstrapBuilder.getInstance(ctx, clientId);
    }

    public void enableLogs() {
        if (vigoBootstrapBuilder != null) {
            vigoBootstrapBuilder.withDebug();
        }
    }

    public void enableUserFeedback() {
        if (vigoBootstrapBuilder != null) {
            vigoBootstrapBuilder.withStars();
        }
    }

    public void setDefaultUserFeedbackLanguage(String locale) {
        if (vigoBootstrapBuilder != null) {
            vigoBootstrapBuilder.withLanguage(locale);
        }
    }

    public boolean initVigoSession(String svcId) {
        if (vigoBootstrapBuilder != null) {
            vigoSession = vigoBootstrapBuilder.getApiSession(svcId);
            if (vigoSession != null) return true;
        }
        return false;
    }

    public boolean initVigoSession(String svcId, Map<String, String> customFields) {
        if (vigoBootstrapBuilder != null) {
            vigoSession = vigoBootstrapBuilder.getApiSession(svcId, customFields);
            if (vigoSession != null) { return true; }
        }
        return false;
    }

    public boolean addSuccessApiMeasurement(final byte category, final int requestRtt, final int requestPt, final long contentLength, final String host)
    {
        if (vigoSession != null) {
            vigoSession.addSuccessApiMeasurement(category, requestRtt, requestPt, contentLength, host);
            return true;
        }

        return false;
    }

    public boolean addErrorApiMeasurement(final byte category, final int requestRtt, final int requestPt, final String host)
    {
        if (vigoSession != null) {
            vigoSession.addErrorApiMeasurement(category, requestRtt, requestPt, host);
            return true;
        }

        return false;
    }

    public boolean countFailedApiMeasurement(final byte category, final String host)
    {
        if (vigoSession != null) {
            vigoSession.countFailedApiMeasurement(category, host);
            return true;
        }

        return false;
    }

    public boolean showFeedbackPopup(Context ctx, PerceptionScenario preceptionScenario, LocationScenario locationScenario, Boolean requestLocation, Boolean isDark, Map<String, String> customFields ) {

        if (vigoSession != null) {

            FeedbackOptions feedbackOptions = new FeedbackOptions(ctx.getApplicationContext());

            if (requestLocation != null) {
                feedbackOptions.requestLocation(requestLocation);

            }
            if (isDark != null) {
                feedbackOptions.requestLocation(isDark);
            }

            if (preceptionScenario != null) {
                feedbackOptions.withPerceptionScenario(preceptionScenario);
            }

            if (locationScenario != null) {
                feedbackOptions.withLocationScenario(locationScenario);
            }

            if (customFields != null && customFields.size() != 0) {
                feedbackOptions.withCustomFields(customFields);
            }

            return vigoSession.showFeedbackPopup(feedbackOptions);
        }

        return false;
    }
}
