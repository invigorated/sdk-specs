package one.vigo;

import android.content.Context;
import android.util.Log;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import vigo.sdk.scenarios.LocationScenario;
import vigo.sdk.scenarios.PerceptionScenario;

@CapacitorPlugin(name = "VigoSdk")
public class VigoSdkPlugin extends Plugin {
    private static final String TAG = "VigoSdkPlugin";

    private static final int PERCEPTION_1 = 1;
    private static final int PERCEPTION_2 = 2;
    private static final int PERCEPTION_3 = 3;
    private static final int PERCEPTION_4 = 4;
    private static final int PERCEPTION_5 = 5;


    private static final int LOCATION_1 = 1;
    private static final int LOCATION_2 = 2;
    private static final int LOCATION_3 = 3;
    private static final int LOCATION_4 = 4;
    private static final int LOCATION_5 = 5;

    private VigoSdk implementation = new VigoSdk();
    private Context context;



    //@Override
    //public void load() {} // Load something during plugin loading

    //Init VigoBootstrapBuilder
    @PluginMethod
    public void initBootstrapBuilder(PluginCall call) {
        JSObject ret = new JSObject();

        try {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Your code to be executed on the main thread
                    context = getContext();

                    // Check for the presence of 'clientId'
                    if (!call.hasOption("clientId")) {
                        ret.put("result", "failed");
                        ret.put("message", "Missing 'clientId'");
                        call.resolve(ret);
                        return;
                    }

                    String clientId = call.getString("clientId");
                    if (clientId == null) {
                        ret.put("result", "failed");
                        ret.put("message", "Wrong value type for 'clientId'");
                        call.resolve(ret);
                        return;
                    }


                    if (context == null) {
                        ret.put("result", "failed");
                        ret.put("message", "Application context is null");
                        call.resolve(ret);
                        return;
                    }

                    implementation.initBootstrapBuilder(context, clientId);
                    ret.put("result", "success");
                    call.resolve(ret);
                }
            });
        }
        catch (Exception e) {
            Log.e(TAG, "Error in initBootstrapBuilder: " + e.getMessage(), e);
            ret.put("result", "failed");
            ret.put("message", "An error occurred");
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void enableLogs(PluginCall call) {
        try {
            implementation.enableLogs();
        }
        catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    @PluginMethod
    public void enableUserFeedback(PluginCall call) {
        try {
            implementation.enableUserFeedback();
        }
        catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    @PluginMethod
    public void setDefaultUserFeedbackLanguage(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            // Check for the presence of 'locale'
            if (!call.hasOption("locale")) {
                ret.put("result", "failed");
                ret.put("message", "Missing 'locale'");
                call.resolve(ret);
                return;
            }

            String locale = call.getString("locale");

            if (locale == null) {
                ret.put("result", "failed");
                ret.put("message", "Wrong value type for 'locale'");
                call.resolve(ret);
                return;
            }

            implementation.setDefaultUserFeedbackLanguage(locale);

            ret.put("result", "success");
            call.resolve(ret);
        }
        catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    @PluginMethod
    public void initVigoSession(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Check for the presence of 'svcId'
                    if (!call.hasOption("svcId")) {
                        ret.put("result", "failed");
                        ret.put("message", "Missing 'svcId'");
                        call.resolve(ret);
                        return;
                    }

                    String svcId = call.getString("svcId");
                    if (implementation.initVigoSession(svcId)) {
                        ret.put("result", "success");
                        call.resolve(ret);
                    } else {
                        ret.put("result", "failed");
                        ret.put("message", "Initialization failed");
                        call.resolve(ret);
                    }
                }
            });
        }
        catch (Exception e) {
            Log.e(TAG, "Error in initVigoSession: " + e.getMessage(), e);
            ret.put("result", "failed");
            ret.put("message", "An error occurred");
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void initVigoSessionCustom(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Check for the presence of 'svcId' and 'customFields' keys
                    if (!call.hasOption("svcId") || !call.hasOption("customFields")) {
                        ret.put("result", "failed");
                        ret.put("message", "Missing 'svcId' or 'customFields'");
                        call.resolve(ret);
                        return;
                    }

                    String svcId = call.getString("svcId");
                    JSObject fields = call.getObject("customFields");

                    // Check if 'fields' is null
                    if (fields == null) {
                        ret.put("result", "failed");
                        ret.put("message", "'customFields' is null");
                        call.resolve(ret);
                        return;
                    }

                    Map<String, String> customFields = new HashMap<>();

                    for (Iterator<String> it = fields.keys(); it.hasNext(); ) {
                        String key = it.next();
                        String value = fields.getString(key);
                        customFields.put(key, value);
                    }

                    if (implementation.initVigoSession(svcId, customFields)) {
                        ret.put("result", "success");
                        call.resolve(ret);
                    } else {
                        ret.put("result", "failed");
                        ret.put("message", "Initialization failed");
                        call.resolve(ret);
                    }
                }
            });
        }
        catch (Exception e) {
            Log.e(TAG, "Error in initVigoSessionCustom: " + e.getMessage(), e);
            ret.put("result", "failed");
            ret.put("message", "An error occurred");
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void addSuccessApiMeasurement(PluginCall call) {
        JSObject ret = new JSObject();
        try {

            if (!call.hasOption("category") || !call.hasOption("rtt")) {
                ret.put("result", "failed");
                ret.put("message", "Missing 'category' or 'rtt'");
                call.resolve(ret);
                return;
            }

            int category = call.getInt("category");
            int rtt = call.getInt("rtt");
            int processTime = call.hasOption("processTime") ? call.getInt("processTime") : -1;
            int contentLength = call.hasOption("contentLength") ? call.getInt("contentLength") : -1;
            String host = call.hasOption("deliveryHost") ? call.getString("deliveryHost") : "";

            if (category <= 0 || category > Byte.MAX_VALUE || rtt < -1 || processTime < -1 || contentLength < -1) {
                ret.put("result", "failed");
                ret.put("message", "Invalid values for 'category' or 'rtt' or 'processTime' or 'contentLength'");
                call.resolve(ret);
                return;
            }

            if (implementation.addSuccessApiMeasurement((byte) category, rtt, processTime, contentLength, host)) {
                ret.put("result", "success");
                call.resolve(ret);
            }
            else {
                ret.put("result", "failed");
                ret.put("message", "Adding measurement failed");
                call.resolve(ret);
            }

        }
        catch (Exception e) {
            Log.e(TAG, "Error in addSuccessApiMeasurement: " + e.getMessage(), e);
            ret.put("result", "failed");
            ret.put("message", "An error occurred");
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void addErrorApiMeasurement(PluginCall call) {
        JSObject ret = new JSObject();
        try {

            if (!call.hasOption("category") || !call.hasOption("rtt")) {
                ret.put("result", "failed");
                ret.put("message", "Missing 'category' or 'rtt'");
                call.resolve(ret);
                return;
            }

            int category = call.getInt("category");
            int rtt = call.getInt("rtt");
            int processTime = call.hasOption("processTime") ? call.getInt("processTime") : -1;
            String host = call.hasOption("deliveryHost") ? call.getString("deliveryHost") : "";

            if (category <= 0 || category > Byte.MAX_VALUE || rtt < -1 || processTime < -1 ) {
                ret.put("result", "failed");
                ret.put("message", "Invalid values for 'category' or 'rtt' or 'processTime'");
                call.resolve(ret);
                return;
            }

            if (implementation.addErrorApiMeasurement((byte) category, rtt, processTime, host)) {
                ret.put("result", "success");
                call.resolve(ret);
            }
            else {
                ret.put("result", "failed");
                ret.put("message", "Adding measurement failed");
                call.resolve(ret);
            }

        }
        catch (Exception e) {
            Log.e(TAG, "Error in addFailedApiMeasurement: " + e.getMessage(), e);
            ret.put("result", "failed");
            ret.put("message", "An error occurred");
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void countFailedApiMeasurement(PluginCall call) {
        JSObject ret = new JSObject();
        try {

            if (!call.hasOption("category")) {
                ret.put("result", "failed");
                ret.put("message", "Missing 'category'");
                call.resolve(ret);
                return;
            }

            int category = call.getInt("category");
            String host = call.hasOption("deliveryHost") ? call.getString("deliveryHost") : "";

            if (category <= 0 || category > Byte.MAX_VALUE ) {
                ret.put("result", "failed");
                ret.put("message", "Invalid values for 'category'");
                call.resolve(ret);
                return;
            }

            if (implementation.countFailedApiMeasurement((byte) category, host)) {
                ret.put("result", "success");
                call.resolve(ret);
            }
            else {
                ret.put("result", "failed");
                ret.put("message", "Adding measurement failed");
                call.resolve(ret);
            }

        }
        catch (Exception e) {
            Log.e(TAG, "Error in countFailedApiMeasurement: " + e.getMessage(), e);
            ret.put("result", "failed");
            ret.put("message", "An error occurred");
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void showFeedbackPopup(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            PerceptionScenario perception = null;
            LocationScenario location = null;
            Boolean requestLocation = null;
            Boolean isDark = null;

            if (context == null) {
                ret.put("result", "failed");
                ret.put("message", "Application context is null");
                call.resolve(ret);
                return;
            }

            if (call.hasOption("perceptionScenario")) {
                Integer perceptionScenario = call.getInt("perceptionScenario");
                if (perceptionScenario == null) {
                    ret.put("result", "failed");
                    ret.put("message", "Invalid values for 'perceptionScenario'");
                    call.resolve(ret);
                    return;
                }
                else {
                    perception = toPerceptionScenario(perceptionScenario);
                    if (perception == null) {
                        ret.put("result", "failed");
                        ret.put("message", "Unknown scenario for 'perceptionScenario'");
                        call.resolve(ret);
                    }
                }
            }

            if (call.hasOption("locationScenario")) {
                Integer locationScenario = call.getInt("locationScenario");
                if (locationScenario == null) {
                    ret.put("result", "failed");
                    ret.put("message", "Invalid values for 'locationScenario'");
                    call.resolve(ret);
                    return;
                }
                else {
                    location = toLocationScenario(locationScenario);
                    if (location == null) {
                        ret.put("result", "failed");
                        ret.put("message", "Unknown scenario for 'locationScenario'");
                        call.resolve(ret);
                    }
                }
            }

            if (call.hasOption("requestLocation")) {
                requestLocation = call.getBoolean("requestLocation");
                if (requestLocation == null) {
                    ret.put("result", "failed");
                    ret.put("message", "Invalid values for 'requestLocation'");
                    call.resolve(ret);
                    return;
                }
            }

            if (call.hasOption("isDark")) {
                isDark = call.getBoolean("isDark");
                if (isDark == null) {
                    ret.put("result", "failed");
                    ret.put("message", "Invalid values for 'isDark'");
                    call.resolve(ret);
                    return;
                }
            }

            JSObject fields = call.getObject("customFields");

            Map<String, String> customFields = new HashMap<>();
            if (fields != null) {
                for (Iterator<String> it = fields.keys(); it.hasNext(); ) {
                    String key = it.next();
                    String value = fields.getString(key);
                    customFields.put(key, value);
                }
            }

            if (implementation.showFeedbackPopup(context, perception, location, requestLocation, isDark, customFields)) {
                ret.put("result", "success");
                call.resolve(ret);
            }
            else {
                ret.put("result", "failed");
                ret.put("message", "Show user feedback failed");
                call.resolve(ret);
            }

        }
        catch (Exception e) {
            Log.e(TAG, "Error in showFeedbackPopup: " + e.getMessage(), e);
            ret.put("result", "failed");
            ret.put("message", "An error occurred");
            call.resolve(ret);
        }
    }

    private PerceptionScenario toPerceptionScenario(Integer perceptionScenario) {
        switch (perceptionScenario) {
            case PERCEPTION_1:
                return PerceptionScenario.PERCEPTION_1;
            case PERCEPTION_2:
                return PerceptionScenario.PERCEPTION_2;
            case PERCEPTION_3:
                return PerceptionScenario.PERCEPTION_3;
            case PERCEPTION_4:
                return PerceptionScenario.PERCEPTION_4;
            case PERCEPTION_5:
                return PerceptionScenario.PERCEPTION_5;
        }
        return null;
    }

    private LocationScenario toLocationScenario(int locationScenario) {
        switch (locationScenario) {
            case 1:
                return LocationScenario.LOCATION_1;
            case 2:
                return LocationScenario.LOCATION_2;
            case 3:
                return LocationScenario.LOCATION_3;
            case 4:
                return LocationScenario.LOCATION_4;
            case 5:
                return LocationScenario.LOCATION_5;
        }
        return null;
    }
}
