export interface VigoSdkPlugin {
  echo(options: { value: string }): Promise<{ value: string }>;
}
