import { WebPlugin } from '@capacitor/core';

import type { VigoSdkPlugin } from './definitions';

export class VigoSdkWeb extends WebPlugin implements VigoSdkPlugin {
  async echo(options: { value: string }): Promise<{ value: string }> {
    console.log('ECHO', options);
    return options;
  }
}
