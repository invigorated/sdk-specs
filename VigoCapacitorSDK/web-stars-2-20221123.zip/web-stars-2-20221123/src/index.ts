import { registerPlugin } from '@capacitor/core';

import type { VigoSdkPlugin } from './definitions';

const VigoSdk = registerPlugin<VigoSdkPlugin>('VigoSdk', {
  web: () => import('./web').then(m => new m.VigoSdkWeb()),
});

export * from './definitions';
export { VigoSdk };
